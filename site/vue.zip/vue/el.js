; const VueEl = (function () {
    return '#vue'
}())
