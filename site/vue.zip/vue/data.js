; const VueData = (function () {
    return {
        site: 'helle zsp vue',
        vHtml: '<h1>v-html</h1>',
        useClass: false,
        vIf: true,
        vShow: true,
        vInput: 'zsp',
        vWatch: 0
    }
}())
